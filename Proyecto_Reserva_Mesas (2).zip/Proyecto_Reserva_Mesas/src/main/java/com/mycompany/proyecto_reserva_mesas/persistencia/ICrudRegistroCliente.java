/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import java.io.Serializable;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public interface ICrudRegistroCliente extends Serializable{
    
    boolean aniadirCliente(Cliente nuevoCliente);
    boolean eliminarCliente(long cedula);
    Cliente buscarCliente(long cedula);
    List<Cliente> obtenerDatos();
}
