
package com.mycompany.proyecto_reserva_mesas.entidades;

public class Validaciones {
    
    public int numero(String numero){
      
        long num;
        
        try {
            
             num= Long.parseLong(numero);
            
            if((num<111111)||(num>2139999999)){
                
                return 1;
            }else{
                
                return 0;
            }
            
        } catch (NumberFormatException e) {
            return 1;
        }
    } 
    
    public int Nombre(String nombre){
      
         if(nombre.matches("[a-zA-Z]+")){
             
             return 0;
             
         }else{
             
              return 1;
         }
    }
     
    public int hora(String num){
        
        try {
            int i=Integer.parseInt(num);
            
            if((i>22)||(i<7)){
               return 1; 
            }else{
                
                return 0;
            }
            
        } catch (NumberFormatException e) {
            
            return 1;
        }
    }
    
    public int mes(String mes){
        
        try {
            int i=Integer.parseInt(mes);
            
            if((i>12)||(i<1)){
               return 1; 
            }else{
                
                return 0;
            }
            
        } catch (NumberFormatException e) {
            
            return 1;
        }
    }
    
    public int anno(String mes){
        
        try {
            int i=Integer.parseInt(mes);
            
            if(i!=2024){
               return 1; 
            }else{
                
                return 0;
            }
            
        } catch (NumberFormatException e) {
            
            return 1;
        }
    }
    
    public int dia(String mes){
        
        try {
            int i=Integer.parseInt(mes);
            
            if((i<1)||(i>31)){
               return 1; 
            }else{
                
                return 0;
            }
            
        } catch (NumberFormatException e) {
            
            return 1;
        }
    }
    
    
}
