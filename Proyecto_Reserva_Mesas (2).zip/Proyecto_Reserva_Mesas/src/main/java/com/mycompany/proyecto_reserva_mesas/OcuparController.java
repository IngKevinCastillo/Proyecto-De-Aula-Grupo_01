/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import com.mycompany.proyecto_reserva_mesas.entidades.Validaciones;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeReservas;
import java.net.URL;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class OcuparController implements Initializable {
    
    @FXML private StackPane rootPaneOcupar;
    @FXML private TextField txtCedulaCliente;
    @FXML private TextField txtIdMesa;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtEstado;
    private listaDeReservas reservas = new listaDeReservas();
    private listaDeMesas mesas = new listaDeMesas();
    private listaDeClientes clientes = new listaDeClientes();
    private GestionReservaController gestionReservaController;
    private Validaciones validar = new Validaciones();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    @FXML
    private void clickBtnGuardar(){
        int i;
        
        i=validar.numero(this.txtCedulaCliente.getText());
        
        if(i==1){
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Cedula no valida");
                alert.show();
        }else{
            long cedula = Long.parseLong(this.txtCedulaCliente.getText());
            int numMesa = Integer.parseInt(this.txtIdMesa.getText());
            String estado = this.txtEstado.getText();
            String codReserva = this.txtCodigo.getText();
            Reserva ocupar = new Reserva(codReserva, this.clientes.buscarCliente(cedula), LocalDate.now(), 
                    LocalTime.now(), this.mesas.buscarMesa(numMesa), estado);
            this.reservas.ocuparMesa(ocupar);

            for(Mesa mesa : this.mesas.getMesas()){
                if(mesa.getNumero() == numMesa){
                    mesa.setEstado("Ocupada");
                }
            }

            if (gestionReservaController != null) {
                gestionReservaController.actualizarTabla();
            }
        }
    }
    
    private void limpiar(){
        this.txtCedulaCliente.setText(null);
        this.txtIdMesa.setText(null);
        this.txtIdMesa.requestFocus();
    }
    
    private void closeWindow() {
        rootPaneOcupar.setVisible(false);
    }
    
    public void setGestionReservaController(GestionReservaController gestionReservaController) {
        this.gestionReservaController = gestionReservaController;
    }
}