package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Validaciones;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

public class AgregarDatosController implements Initializable {

    @FXML private Button btnSalir;
    @FXML private StackPane rootPane;
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellido;
    @FXML private TextField txtCedula;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private ComboBox<String> cmbGenero;
    private listaDeClientes clientes = new listaDeClientes();
    private GestionClientesController gestionClientesController;
    private Validaciones validar = new Validaciones();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.cmbGenero.getItems().addAll("Masculino", "Femenino");
    }

    @FXML
    private void clickBtnGuardar() {
        int i=0;
        
        i=validar.numero(this.txtTelefono.getText());
        
        if(i==1){
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Telefono no valido");
                alert.show();
        }else{
            
            i=validar.numero(this.txtCedula.getText());
            
            if(i==1){
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Numero Cedula");
                alert.show();
            }else{
                long telefono = Long.parseLong(this.txtTelefono.getText());
                String nombre = this.txtNombre.getText();
                String apellido = this.txtApellido.getText();
                long cedula = Long.parseLong(this.txtCedula.getText());
                String correo = this.txtCorreo.getText();
                String genero = this.cmbGenero.getSelectionModel().getSelectedItem().toString();
                Cliente c = new Cliente(telefono, nombre, apellido, cedula, genero, correo);
                this.clientes.añadirCliente(c);
                System.out.println(this.clientes.getClientes().size() + " registrados");

                if (gestionClientesController != null) {
                    gestionClientesController.actualizarTabla();
                }
            }
        }
    }

    @FXML
    private void clickBtnSalir() {
        this.limpiar();
        this.closeWindow();
    }

    private void closeWindow() {
        rootPane.setVisible(false);
    }

    public void limpiar() {
        this.txtApellido.setText(null);
        this.txtCedula.setText(null);
        this.txtCorreo.setText(null);
        this.txtNombre.setText(null);
        this.txtTelefono.setText(null);
        this.txtCedula.requestFocus();
        this.txtTelefono.requestFocus();
    }

    public void setGestionClientesController(GestionClientesController gestionClientesController) {
        this.gestionClientesController = gestionClientesController;
    }
}
