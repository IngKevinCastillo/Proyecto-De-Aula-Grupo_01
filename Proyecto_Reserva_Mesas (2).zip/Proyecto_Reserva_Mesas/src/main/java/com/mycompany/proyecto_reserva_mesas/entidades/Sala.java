/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;
import java.util.*;

/**
 *
 * @author Fabian Hinojosa
 */
public class Sala implements Serializable{
    private static final long serialVersionUID = 1L;
    private ArrayList<Mesa> mesas;
    private int salas;
    private String descripcion;

    public Sala( int salas, String descripcion) {
       this.descripcion = descripcion;
       this.salas = salas;
    }
    
    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        this.descripcion = descripcion;
    }

    public int getSala() {
        return salas;
    }

    public void setoSala(int salas) {
        this.salas = salas;
    }
    
    public void agregarUnaMesa(Mesa mesa){
        this.mesas.add(mesa);
    }
    
    public ArrayList<Mesa> getMesas() {
        return mesas;
    }

    public void setMesas(ArrayList<Mesa> mesas) {
        this.mesas = mesas;
    }
    
    public Mesa buscarMesa(int mesa){
        if (mesas != null) {
            for (Mesa m : this.mesas) {
                if (m.getNumero() == mesa) {
                    return m;
                }
            }
        }
        return null;
    }
    
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("Datos: \n");
        for (Mesa mesa : mesas) {
            sb.append("Mesa ").append(mesa.getNumero())
                    .append(": ").append(salas).append("\n");
        }
        return sb.toString();
    }

    
    
}