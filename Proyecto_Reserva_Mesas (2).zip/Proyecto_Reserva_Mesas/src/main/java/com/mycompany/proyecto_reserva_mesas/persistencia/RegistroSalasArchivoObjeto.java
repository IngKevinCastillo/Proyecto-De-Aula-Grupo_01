package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import java.io.*;
import java.util.List;

public class RegistroSalasArchivoObjeto implements ICrudRegistroSala {
    private File archivo;
    private FileOutputStream aEscritura;
    private FileInputStream aLectura;

    public RegistroSalasArchivoObjeto(String name) {
        this.archivo = new File(name);
        crearArchivoSiNoExiste();
    }

    public RegistroSalasArchivoObjeto() {
        this("salas.obj");
    }

    private void crearArchivoSiNoExiste() {
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo: " + ex.getMessage());
        }
    }

    private ICrudRegistroSala leer() {
        ICrudRegistroSala coleccion = null;
        if (!this.archivo.exists() || this.archivo.length() == 0) {
            System.out.println("Archivo no existe o está vacío. Creando nueva colección.");
            return new RegistroSalasImpArrayList();
        }
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(this.archivo))) {
            coleccion = (ICrudRegistroSala) ois.readObject();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de lectura: " + ex.getMessage());
        } catch (InvalidClassException ex) {
            System.out.println("Incompatibilidad de versión: " + ex.getMessage());
            coleccion = new RegistroSalasImpArrayList();
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de lectura: " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al leer objeto: " + ex.getMessage());
        }
        if (coleccion == null) {
            coleccion = new RegistroSalasImpArrayList();
        }
        return coleccion;
    }

    private void guardar(ICrudRegistroSala coleccion) {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(this.archivo))) {
            oos.writeObject(coleccion);
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de escritura: " + ex.getMessage());
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de escritura: " + ex.getMessage());
        }
    }

    @Override
    public Sala buscarSala(int numSala) {
        ICrudRegistroSala coleccion = this.leer();
        if (coleccion == null) {
            System.out.println("Colección leída es null.");
        }
        return coleccion.buscarSala(numSala);
    }

    @Override
    public boolean crearSala(Sala sala) {
        ICrudRegistroSala coleccion = this.leer();
        boolean resultado = coleccion.crearSala(sala);
        this.guardar(coleccion);
        return resultado;
    }

    @Override
    public List<Sala> getSalas() {
        ICrudRegistroSala coleccion = this.leer();
        if (coleccion == null) {
            System.out.println("Colección leída es null.");
        }
        return coleccion.getSalas();
    }

    @Override
    public boolean eliminarSala(int salaEliminar) {
        ICrudRegistroSala coleccion = this.leer();
        boolean resultado = coleccion.eliminarSala(salaEliminar);
        this.guardar(coleccion);
        return resultado;
    }
}
