
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;

public class Gerente extends Usuario implements Serializable{

    public Gerente() {
    }

    public Gerente(String usuario, String contraseña, String nombre, String apellido, long cedula, String genero) {
        super(usuario, contraseña, nombre, apellido, cedula, genero);
        
        if (permisos == null) {
            permisos = new Permisos();
        }
        
        permisos.setGestionReserv(false);
        permisos.setGestionSalas(true);
        permisos.setGestionUsuario(true);
        permisos.setGestionMesas(true);
    }

    @Override
    public String toString() {
        return super.toString();
    }
}
