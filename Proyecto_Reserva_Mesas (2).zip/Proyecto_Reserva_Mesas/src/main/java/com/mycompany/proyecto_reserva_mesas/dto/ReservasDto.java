/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.dto;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.time.LocalDate;
import java.time.LocalTime;
import javafx.beans.property.*;
/**
 *
 * @author Fabian Hinojosa
 */
public class ReservasDto {
    private SimpleLongProperty cliente;
    private SimpleStringProperty codReserva;
    private SimpleObjectProperty<LocalDate> fechaDeReserva;
    private SimpleObjectProperty<LocalTime> HoraDeReserva;
    private SimpleIntegerProperty mesaReservar;
    private SimpleStringProperty estadoReserva;
    
    public ReservasDto(Reserva obj){
        this.cliente = new SimpleLongProperty(obj.getCliente().getCedula());
        this.codReserva = new SimpleStringProperty(obj.getCodReserva());
        this.fechaDeReserva = new SimpleObjectProperty<>(obj.getFechaDeReserva());
        this.HoraDeReserva = new SimpleObjectProperty<>(obj.getHoraDeReserva());
        this.mesaReservar = new SimpleIntegerProperty(obj.getMesaReservar().getNumero());
        this.estadoReserva = new SimpleStringProperty(obj.getEstadoReserva());
    }
    
    public Long getCliente(){
        return cliente.get();
    }
    
    public void setCliente(Long cliente){
        this.cliente.set(cliente);
    }
    
    public String getCodReserva(){
        return codReserva.get();
    }
    
    public void SetCodReserva(String codReserva){
        this.codReserva.set(codReserva);
    }
    
    public LocalDate getFechaDeReserva(){
        return fechaDeReserva.get();
    }
    
    public void setFechaDeReserva(LocalDate fechaDeReserva){
        this.fechaDeReserva.set(fechaDeReserva);
    }
    
    public LocalTime getHoraDeReserva(){
        return HoraDeReserva.get();
    }
    
    public void setHoraDeReserva(LocalTime horaDeReserva){
        this.HoraDeReserva.set(horaDeReserva);
    }
    
    public int getMesaReservar(){
        return mesaReservar.get();
    }
    
    public void setMesaReservar(int mesaReservar){
        this.mesaReservar.set(mesaReservar);
    }
    
    public String getEstadoReserva(){
        return estadoReserva.get();
    }
    
    public void setEstadoReserva(String estadoReserva){
        this.estadoReserva.set(estadoReserva);
    }
}
