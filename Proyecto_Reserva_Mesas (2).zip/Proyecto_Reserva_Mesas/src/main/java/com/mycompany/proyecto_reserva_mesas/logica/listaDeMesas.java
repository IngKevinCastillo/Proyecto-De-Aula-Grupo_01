/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.logica;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import java.util.List;
import com.mycompany.proyecto_reserva_mesas.persistencia.ICrudRegistroMesa;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroMesasArchivoObjeto;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroMesasImpArrayList;

/**
 *
 * @author Fabian Hinojosa
 */
public class listaDeMesas {
    //private List<Mesa> listaMesas;
    private ICrudRegistroMesa persistencia;
    
    public listaDeMesas(){
        this.persistencia = new RegistroMesasArchivoObjeto();
    }

    public ICrudRegistroMesa getPersistencia() {
        return persistencia;
    }

    public void setPersistencia(ICrudRegistroMesa persistencia) {
        this.persistencia = persistencia;
    }
    
    public boolean crearMesa(int numMesa, int numAcientos){
        Mesa mesa = new Mesa(numMesa, numAcientos);
        return this.persistencia.crearMesa(mesa);
    }
    
    public Mesa buscarMesa(int numMesa){
        return this.persistencia.buscarMesa(numMesa);
    }
    
    public void agregarMesaASala(int numSala, int numMesa){
        this.persistencia.agregarMesaASala(numSala, numMesa);
    }
    
    public List<Mesa> getMesas(){
        return this.persistencia.getMesas();
    }
    
    public boolean eliminarMesa(int id){
        return this.persistencia.eliminarMesa(id);
    }
}
