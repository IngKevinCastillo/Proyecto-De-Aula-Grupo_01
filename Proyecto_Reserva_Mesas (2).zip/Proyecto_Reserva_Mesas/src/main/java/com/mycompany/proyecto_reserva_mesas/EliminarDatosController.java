/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Validaciones;
import java.net.URL;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class EliminarDatosController implements Initializable {

    @FXML private TextField txtCedula;
    @FXML private StackPane rootPane;
    private final listaDeClientes CLIENTES = new listaDeClientes();
    private GestionClientesController gestionClientesController;
    private Validaciones validar= new Validaciones();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    @FXML
    private void clickEliminarDato(){
        
        if(validar.numero(this.txtCedula.getText())==1){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Cedula no valida");
                alert.show();
            
        }else{
            
            long cedula = Long.parseLong(this.txtCedula.getText());
            this.CLIENTES.eliminarCliente(cedula);

            if (gestionClientesController != null) {
                gestionClientesController.actualizarTabla();
            }
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }

    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void limpiar(){
        this.txtCedula.setText(null);
        this.txtCedula.requestFocus();
    }
    
    public void setGestionClientesController(GestionClientesController gestionClientesController) {
        this.gestionClientesController = gestionClientesController;
    }
}
