package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RegistroUsuariosImpArrayList implements Serializable, ICrudRegistroUsuarios {
    private static final long serialVersionUID = -3212387369645442591L;
    private List<Usuario> listaUsuarios;
    
    public RegistroUsuariosImpArrayList(){
        this.listaUsuarios = new ArrayList<>();
    }

    @Override
    public boolean añadirUsuario(Usuario nuevo) {
        return this.listaUsuarios.add(nuevo);
    }

    @Override
    public boolean eliminarUsuario(String usuario) {
        for(Usuario a : this.listaUsuarios){
            if(a.getUsuario().equals(usuario)){
                listaUsuarios.remove(a);
                return true;
            }
        }
        return false;
    }

    @Override
    public Usuario buscarUsuario(String username) {
        for(Usuario a : this.listaUsuarios){
            if(a.getUsuario().equals(username)){
                return a;
            }
        }
        return null;
    }

    @Override
    public List<Usuario> obtenerDatos() {
        return this.listaUsuarios;
    }

    @Override
    public String cambiarContrasenia(String username, String contrasenia) {
        Usuario x = buscarUsuario(username);
        if(x == null){
            return "No existe el usuario consultado";
        } else {
            x.setContraseña(contrasenia);
            return "La contrasenia ha sido cambiada con exito.";
        }
    }
}
