/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.dto.SalasDto;
import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeSalas;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class GestionSalasController implements Initializable {
    
    @FXML private TableView tablaSalas;
    @FXML private TableColumn colSalasId;
    @FXML private TableColumn colSalasDescripcion;
    
    @FXML private StackPane panelOpciones;
    @FXML private Button btnAgregar;
    @FXML private Button btnEliminar;
    @FXML private Button btnBuscar;
    private ObservableList<SalasDto> listadoSalas;
    private listaDeSalas salas = new listaDeSalas();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnAgregar.setOnAction(event ->{
            try {
                cargarPanel("agregarSala");
            } catch (IOException ex) {
            }
        });
        
        btnBuscar.setOnAction(event ->{
            try {
                cargarPanel("buscarSala");
            } catch (IOException ex) {
            }
        });
        
        btnEliminar.setOnAction(event ->{
            try {
                cargarPanel("eliminarSala");
            } catch (IOException ex) {
            }
        });
        
        colSalasId.setCellValueFactory(new PropertyValueFactory<>("salas"));
        colSalasDescripcion.setCellValueFactory(new PropertyValueFactory<>("descripcion"));
        
        this.cargarConsulta();
    }    
    
    private void cargarPanel(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml + ".fxml"));
        StackPane nuevoPanel = loader.load();
        panelOpciones.getChildren().setAll(nuevoPanel);
        
        if (fxml.equals("agregarSala")) {
            AgregarSalaController controller = loader.getController();
            controller.setGestionClientesController(this);
        }
        
        if (fxml.equals("buscarSala")) {
            BuscarSalaController controller = loader.getController();
            controller.setGestionClientesController(this);
        }
        
        if (fxml.equals("eliminarSala")) {
            EliminarSalaController controller = loader.getController();
            controller.setGestionClientesController(this);
        }
    }
    
    public void cargarConsulta(){
        this.listadoSalas = FXCollections.observableArrayList();
        for(Sala a : this.salas.getSala()){
            SalasDto dto = new SalasDto(a);
            this.listadoSalas.add(dto);
        }
        
        this.tablaSalas.setItems(this.listadoSalas);
    }
    
    public void actualizarTabla() {
        this.listadoSalas.clear();
        for (Sala a : this.salas.getSala()) {
            SalasDto dto = new SalasDto(a);
            this.listadoSalas.add(dto);
        }
        this.tablaSalas.refresh();
    }
}
