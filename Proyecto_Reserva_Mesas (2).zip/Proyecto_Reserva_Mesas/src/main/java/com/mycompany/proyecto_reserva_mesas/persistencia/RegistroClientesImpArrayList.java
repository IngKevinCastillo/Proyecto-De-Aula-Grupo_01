package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RegistroClientesImpArrayList implements Serializable, ICrudRegistroCliente {
    private static final long serialVersionUID = 1L;
    private List<Cliente> listaClientes;

    public RegistroClientesImpArrayList() {
        this.listaClientes = new ArrayList<>();
    }
    
    @Override
    public boolean aniadirCliente(Cliente nuevoCliente) {
        System.out.println("Agregado Correctamente.");
        return this.listaClientes.add(nuevoCliente);
    }

    @Override
    public boolean eliminarCliente(long cedula) {
        for(Cliente a : this.listaClientes){
            if(a.getCedula() == cedula){
                return this.listaClientes.remove(a);
            }
        }
        return false;
    }

    @Override
    public Cliente buscarCliente(long cedula) {
        for (Cliente a : this.listaClientes) {
            if (a.getCedula() == cedula) {
                System.out.println("Cliente encontrado: " + a.toString());
                return a;
            }
        }
        return null;
    }

    @Override
    public List<Cliente> obtenerDatos() {
        return this.listaClientes;
    }
}
