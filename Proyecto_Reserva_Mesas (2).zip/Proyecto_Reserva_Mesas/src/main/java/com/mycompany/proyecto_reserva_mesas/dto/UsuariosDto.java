/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.dto;

import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import javafx.beans.property.*;

/**
 *
 * @author Fabian Hinojosa
 */
public class UsuariosDto {
    private SimpleStringProperty usuario;
    private SimpleStringProperty contraseña;
    private SimpleStringProperty nombre;
    private SimpleStringProperty apellido;
    private SimpleLongProperty cedula;
    private SimpleStringProperty genero;
    private SimpleStringProperty tipo;
    
    public UsuariosDto(Usuario obj){
        this.usuario = new SimpleStringProperty(obj.getUsuario());
        this.contraseña = new SimpleStringProperty(obj.getContraseña());
        this.nombre = new SimpleStringProperty(obj.getNombre());
        this.apellido = new SimpleStringProperty(obj.getApellido());
        this.cedula = new SimpleLongProperty(obj.getCedula());
        this.genero = new SimpleStringProperty(obj.getGenero());
        this.tipo = new SimpleStringProperty(obj.getTipo());
    }
    
    public String getUsuario(){
        return usuario.get();
    }
    
    public void setUsuario(String usuario){
        this.usuario.set(usuario);
    }
    
    public String getContraseña(){
        return contraseña.get();
    }
    
    public void setContraseña(String contraseña){
        this.contraseña.set(contraseña);
    }
    
    public String getNombre(){
        return nombre.get();
    }
    
    public void setNombre(String nombre){
        this.nombre.set(nombre);
    }
    
    public String getApellido(){
        return apellido.get();
    }
    
    public void setApellido(String apellido){
        this.apellido.set(apellido);
    }
    
    public long getCedula(){
        return cedula.get();
    }
    
    public void setCedula(long cedula){
        this.cedula.set(cedula);
    }
    
    public String getGenero(){
        return genero.get();
    }
    
    public void setGenero(String genero){
        this.genero.set(genero);
    }
    
    public String getTipo(){
        return tipo.get();
    }
    
    public void setTipo(String tipo){
        this.tipo.set(tipo);
    }
}
