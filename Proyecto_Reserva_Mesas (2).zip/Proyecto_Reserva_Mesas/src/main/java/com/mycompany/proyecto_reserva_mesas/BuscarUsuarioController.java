/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.logica.listaDeUsuarios;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class BuscarUsuarioController implements Initializable {

    @FXML private TextField txtUsername;
    @FXML private StackPane rootPane;
    private final listaDeUsuarios USUARIOS = new listaDeUsuarios();
    private GestionUsuariosController gestionUsuariosController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    
    @FXML
    private void clickBtnConfirmar(){
        String username = this.txtUsername.getText();
        this.USUARIOS.buscarUsuario(username);
        
        if (gestionUsuariosController != null) {
            gestionUsuariosController.actualizarTabla();
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtUsername.setText(null);
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void setGestionUsuariosController(GestionUsuariosController gestionUsuariosController) {
        this.gestionUsuariosController = gestionUsuariosController;
    }
}
