/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.dto.ReservasDto;
import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeReservas;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class GestionReservaController implements Initializable {
    
    @FXML private TableView tablaReserva;
    @FXML private TableColumn colCliente;
    @FXML private TableColumn colCodigo;
    @FXML private TableColumn colFecha;
    @FXML private TableColumn colHora;
    @FXML private TableColumn colMesa;
    @FXML private TableColumn colEstado;
    
    @FXML private Button btnOcupar;
    @FXML private Button btnReservar;
    @FXML private Button btnDesocupar;
    @FXML private Button btnBuscar;
    @FXML private Button btnQuitarReserva;
    @FXML private StackPane panelOpciones;
    private ObservableList<ReservasDto> listadoReservas;
    private listaDeReservas reservas = new listaDeReservas();

    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnOcupar.setOnAction(event -> {
            try{
                cargarPanel("ocupar");
            }catch(IOException e){
            }
        });
        
        btnReservar.setOnAction(event -> {
            try{
                cargarPanel("reservar");
            }catch(IOException e){
            }
        });
        
        btnDesocupar.setOnAction(event -> {
            try{
                cargarPanel("desocupar");
            }catch(IOException e){
            }
        });
        
        btnQuitarReserva.setOnAction(event -> {
            try{
                cargarPanel("eliminarReserva");
            }catch(IOException e){
            }
        });
        
        btnBuscar.setOnAction(event -> {
            try{
                cargarPanel("buscarReserva");
            }catch(IOException e){
            }
        });
        
        this.colCliente.setCellValueFactory(new PropertyValueFactory("cliente"));
        this.colCodigo.setCellValueFactory(new PropertyValueFactory("codReserva"));
        this.colFecha.setCellValueFactory(new PropertyValueFactory("fechaDeReserva"));
        this.colHora.setCellValueFactory(new PropertyValueFactory("HoraDeReserva"));
        this.colMesa.setCellValueFactory(new PropertyValueFactory("mesaReservar"));
        this.colEstado.setCellValueFactory(new PropertyValueFactory("estadoReserva"));
        
        this.cargarConsulta();
    }
    
    private void cargarPanel(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml + ".fxml"));
        StackPane nuevoPanel = loader.load();
        panelOpciones.getChildren().setAll(nuevoPanel);
        
        if (fxml.equals("ocupar")) {
            OcuparController controller = loader.getController();
            controller.setGestionReservaController(this);
        }
        
        if (fxml.equals("reservar")) {
            ReservarController controller = loader.getController();
            controller.setGestionReservaController(this);
        }
        
        if (fxml.equals("desocupar")) {
            DesocuparController controller = loader.getController();
            controller.setGestionReservaController(this);
        }
        
        if (fxml.equals("eliminarReserva")) {
            EliminarReservaController controller = loader.getController();
            controller.setGestionReservaController(this);
        }
        
        if (fxml.equals("buscarReserva")) {
            BuscarReservaController controller = loader.getController();
            controller.setGestionReservaController(this);
        }
    }
    
    public void cargarConsulta(){
        this.listadoReservas = FXCollections.observableArrayList();
        for(Reserva a : this.reservas.obtenerReservas()){
            ReservasDto dto = new ReservasDto(a);
            this.listadoReservas.add(dto);
        }
        
        this.tablaReserva.setItems(this.listadoReservas);
    }
    
    public void actualizarTabla() {
        this.listadoReservas.clear();
        for (Reserva a : this.reservas.obtenerReservas()) {
            ReservasDto dto = new ReservasDto(a);
            this.listadoReservas.add(dto);
        }
        this.tablaReserva.refresh();
    }
}
