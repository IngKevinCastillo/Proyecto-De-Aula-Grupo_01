/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonType;
import javafx.scene.control.MenuItem;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class HomeController implements Initializable {

    @FXML private Button btnSalir;
    @FXML private MenuItem btnGestionSalas;
    @FXML private MenuItem menuBtnGestionClientes;
    @FXML private MenuItem btnGestionMesas;
    @FXML private MenuItem btnGestionUsuario;
    @FXML private MenuItem btnGestionReserva;
    @FXML private StackPane panelTrabajo;
    private Stage stage;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnGestionMesas.setOnAction(event -> {
            try{
                cargarPanel("gestionMesas");
            }catch(IOException e){
            }
        });
        
        menuBtnGestionClientes.setOnAction(event ->{
            try{
                cargarPanel("gestionClientes");
            }catch(IOException e){
            }
        });
        
        btnGestionReserva.setOnAction(event -> {
            try{
                cargarPanel("gestionReserva");
            }catch(IOException e){
            }
        });
        
        btnGestionSalas.setOnAction(event ->{
            try{
                cargarPanel("gestionSalas");
            }catch(IOException e){
            }
        });
        
        btnGestionUsuario.setOnAction(event -> {
            try{
                cargarPanel("gestionUsuario");
            }catch(IOException e){
            }
        });
    }

    /*@FXML
    private void clickMenuBtnGestionClientes() {
        this.panelClientes.setVisible(true);
    }*/

    @FXML
    private void clickImagenLogo() {
        //this.panelClientes.setVisible(false);
        this.panelTrabajo.getChildren().clear();
    }

    @FXML
    private void clickBtnSalir() {
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("¿Está seguro que desea salir?");
        alert.setTitle("Confirmación de salida");

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            stage = (Stage) btnSalir.getScene().getWindow();
            stage.close();
        } else {
            alert.close();
        }
    }
    
    @FXML
    private void clickLogOut(){
        
        Alert alert = new Alert(Alert.AlertType.CONFIRMATION);
        alert.setHeaderText("¿Está seguro que desea Cerrar Sesion?");
        alert.setTitle("Confirmación de Cerrar Sesion");

        Optional<ButtonType> result = alert.showAndWait();

        if (result.isPresent() && result.get() == ButtonType.OK) {
            try {
                App.setStage("login");
            } catch (IOException ex) {
                System.out.println("ERROR AL CERRAR SESION.");
            }
        } else {
            alert.close();
        }
    }
    
    private void cargarPanel(String fxml) throws IOException {
        StackPane nuevoPanel = (StackPane) App.loadFXML(fxml);
        panelTrabajo.getChildren().setAll(nuevoPanel);
    }
}
