/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.dto;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import javafx.beans.property.*;

/**
 *
 * @author Fabian Hinojosa
 */
public class MesasDto {
    private SimpleIntegerProperty id;
    private SimpleIntegerProperty asientos;
    private SimpleStringProperty estado;
    private SimpleObjectProperty<Sala> ubicacionSala;
    
    public MesasDto(Mesa obj){
        this.id = new SimpleIntegerProperty(obj.getNumero());
        this.asientos = new SimpleIntegerProperty(obj.getNumeroDeAsientos());
        this.estado = new SimpleStringProperty(obj.getEstado());
        this.ubicacionSala = new SimpleObjectProperty<>(obj.getUbicacionSala());
    }
    
    public int getId(){
        return id.get();
    }
    
    public void setId(int id){
        this.id.set(id);
    }
    
    public int getAsientos(){
        return asientos.get();
    }
    
    public void setAsientos(int asientos){
        this.asientos.set(asientos);
    }
    
    public String getEstado(){
        return estado.get();
    }
    
    public void setEstado(String estado){
        this.estado.set(estado);
    }
    
    public Sala getUbicacionSala(){
        return ubicacionSala.get();
    }
    
    public void setUbicacioSala(Sala ubicacionSala){
        this.ubicacionSala.set(ubicacionSala);
    }
}
