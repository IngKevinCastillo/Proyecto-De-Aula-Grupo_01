package com.mycompany.proyecto_reserva_mesas.dto;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import javafx.beans.property.SimpleLongProperty;
import javafx.beans.property.SimpleStringProperty;

public class ClientesDto {
    private SimpleLongProperty numTelefono;
    private SimpleStringProperty nombre;
    private SimpleStringProperty apellido;
    private SimpleLongProperty cedula;
    private SimpleStringProperty genero;
    private SimpleStringProperty correoPer;

    public ClientesDto(Cliente obj) {
        this.numTelefono = new SimpleLongProperty(obj.getNumTelefono());
        this.nombre = new SimpleStringProperty(obj.getNombre());
        this.apellido = new SimpleStringProperty(obj.getApellido());
        this.cedula = new SimpleLongProperty(obj.getCedula());
        this.genero = new SimpleStringProperty(obj.getGenero());
        this.correoPer = new SimpleStringProperty(obj.getCorreoPer());
    }

    public long getNumTelefono() {
        return numTelefono.get();
    }

    public void setNumTelefono(long numTelefono) {
        this.numTelefono.set(numTelefono);
    }

    public String getNombre() {
        return nombre.get();
    }

    public void setNombre(String nombre) {
        this.nombre.set(nombre);
    }

    public String getApellido() {
        return apellido.get();
    }

    public void setApellido(String apellido) {
        this.apellido.set(apellido);
    }

    public long getCedula() {
        return cedula.get();
    }

    public void setCedula(long cedula) {
        this.cedula.set(cedula);
    }

    public String getGenero() {
        return genero.get();
    }

    public void setGenero(String genero) {
        this.genero.set(genero);
    }

    public String getCorreoPer() {
        return correoPer.get();
    }

    public void setCorreoPer(String correoPer) {
        this.correoPer.set(correoPer);
    }
}
