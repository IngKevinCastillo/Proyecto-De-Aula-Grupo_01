/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.dto.UsuariosDto;
import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeUsuarios;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class GestionUsuariosController implements Initializable {
    @FXML private TableView tablaUsuarios;
    @FXML private TableColumn colNombre;
    @FXML private TableColumn colApellido;
    @FXML private TableColumn colCedula;
    @FXML private TableColumn colGenero;
    @FXML private TableColumn colUsuario;
    @FXML private TableColumn colContraseña;
    @FXML private TableColumn colTipo;
    
    @FXML private Button btnAgregar;
    @FXML private Button btnEliminar;
    @FXML private Button btnBuscar;
    @FXML private Button btnActualizar;
    @FXML private StackPane panelUsuarios;
    private ObservableList<UsuariosDto> listadoUsuarios;
    private listaDeUsuarios usuarios = new listaDeUsuarios();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnAgregar.setOnAction(event -> {
            try{
                cargarPanel("agregarUsuario");
            }catch(IOException e){
            }
        });
        
        btnEliminar.setOnAction(event -> {
            try{
                cargarPanel("eliminarUsuario");
            }catch(IOException e){
            }
        });
        
        btnBuscar.setOnAction(event -> {
            try{
                cargarPanel("buscarUsuario");
            }catch(IOException e){
            }
        });
        
        btnActualizar.setOnAction(event -> {
            try{
                cargarPanel("actualizarUsuario");
            }catch(IOException e){
            }
        });
        
        this.colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.colApellido.setCellValueFactory(new PropertyValueFactory("apellido"));
        this.colCedula.setCellValueFactory(new PropertyValueFactory("cedula"));
        this.colGenero.setCellValueFactory(new PropertyValueFactory("genero"));
        this.colUsuario.setCellValueFactory(new PropertyValueFactory("usuario"));
        this.colContraseña.setCellValueFactory(new PropertyValueFactory("contraseña"));
        this.colTipo.setCellValueFactory(new PropertyValueFactory("tipo"));
        
        this.cargarConsulta();
    }    
    
    private void cargarPanel(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml + ".fxml"));
        StackPane nuevoPanel = loader.load();
        panelUsuarios.getChildren().setAll(nuevoPanel);
        
        if (fxml.equals("agregarUsuario")) {
            AgregarUsuarioController controller = loader.getController();
            controller.setGestionUsuariosController(this);
        }
        
        if (fxml.equals("eliminarUsuario")) {
            EliminarUsuarioController controller = loader.getController();
            controller.setGestionUsuariosController(this);
        }
        
        if (fxml.equals("buscarUsuario")) {
            BuscarUsuarioController controller = loader.getController();
            controller.setGestionUsuariosController(this);
        }
    }
    
    public void cargarConsulta(){
        this.listadoUsuarios = FXCollections.observableArrayList();
        for(Usuario a : this.usuarios.obtenerDatos()){
            UsuariosDto dto = new UsuariosDto(a);
            this.listadoUsuarios.add(dto);
        }
        
        this.tablaUsuarios.setItems(this.listadoUsuarios);
    }
    
    public void actualizarTabla(){
        this.listadoUsuarios.clear();
        for(Usuario a : this.usuarios.obtenerDatos()){
            UsuariosDto dto = new UsuariosDto(a);
            this.listadoUsuarios.add(dto);
        }
        
        this.tablaUsuarios.refresh();
    }
}
