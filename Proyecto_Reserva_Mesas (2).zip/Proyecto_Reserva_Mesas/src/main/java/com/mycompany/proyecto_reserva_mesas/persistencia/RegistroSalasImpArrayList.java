package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class RegistroSalasImpArrayList implements ICrudRegistroSala, Serializable {
    private static final long serialVersionUID = 1L;
    private List<Sala> listaSalas;
    
    public RegistroSalasImpArrayList(){
        this.listaSalas = new ArrayList<>();
    }

    public List<Sala> getListaSalas() {
        return listaSalas;
    }

    public void setListaSalas(List<Sala> listaSalas) {
        this.listaSalas = listaSalas;
    }

    @Override
    public Sala buscarSala(int numSala) {
        for(Sala a : this.listaSalas){
            if(a.getSala() == numSala){
                return a;
            }
        }
        return null;
    }

    @Override
    public boolean crearSala(Sala sala) {
        return this.listaSalas.add(sala);
    }

    @Override
    public List<Sala> getSalas() {
        return this.listaSalas;
    }

    @Override
    public boolean eliminarSala(int salaEliminar) {
        for(Sala s : this.listaSalas){
            if(s.getSala() == salaEliminar){
                this.listaSalas.remove(s);
                return true;
            }
        }
        
        return false;
    }
}
