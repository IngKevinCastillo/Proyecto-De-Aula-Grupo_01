/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Gerente;
import com.mycompany.proyecto_reserva_mesas.entidades.Recepcionista;
import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import com.mycompany.proyecto_reserva_mesas.entidades.Validaciones;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeUsuarios;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class AgregarUsuarioController implements Initializable {
    
    @FXML private TextField txtCedula;
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellido;
    @FXML private TextField txtUsername;
    @FXML private TextField txtContraseña;
    @FXML private ComboBox cmbGenero;
    @FXML private ComboBox cmbTipo;
    @FXML private StackPane rootPane;
    private final listaDeUsuarios USUARIO = new listaDeUsuarios();
    private GestionUsuariosController gestionUsuariosController;
    private Validaciones validar = new Validaciones();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.cmbGenero.getItems().addAll("Masculino", "Femenino");
        this.cmbTipo.getItems().addAll("Gerente","Recepcionista");
    }
    
    @FXML
    private void clickBtnConfirmar(){
        int i;
        String usuario = this.txtUsername.getText();
        String contraseña = this.txtContraseña.getText();
        
        i=validar.Nombre(this.txtNombre.getText());
        
        if(i==1){
                
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Nombre  no valido");
                alert.show();
        }else{
            
            i=validar.Nombre(this.txtApellido.getText());
        
            if(i==1){

                    Alert alert = new Alert(Alert.AlertType.ERROR);
                    alert.setTitle("Error");
                    alert.setHeaderText("Apellido  no valido");
                    alert.show();
            }else{
                
                i=validar.Nombre(this.txtApellido.getText());
        
                if(i==1){

                        Alert alert = new Alert(Alert.AlertType.ERROR);
                        alert.setTitle("Error");
                        alert.setHeaderText("Cedula  no valida");
                        alert.show();
                }else{
                    String nombre = this.txtNombre.getText();
                    String apellido = this.txtApellido.getText();
                    long cedula = Long.parseLong(this.txtCedula.getText());
                    String genero = this.cmbGenero.getSelectionModel().getSelectedItem().toString();
                    String tipo = this.cmbTipo.getSelectionModel().getSelectedItem().toString();
                    if("Gerente".equals(tipo)){
                        Usuario gerente = new Gerente(usuario, contraseña, nombre, apellido, cedula, genero);
                        gerente.setTipo("Gerente");
                        this.USUARIO.registrarUsuario(gerente);

                    }else{
                        Usuario recepcionista = new Recepcionista(usuario, contraseña, nombre, apellido, cedula, genero);
                        recepcionista.setTipo("Recepcionista");
                        this.USUARIO.registrarUsuario(recepcionista);
                    }
                    this.USUARIO.obtenerDatos();

                    if (gestionUsuariosController != null) {
                        gestionUsuariosController.actualizarTabla();
                    }
                }
            }
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }

    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void limpiar(){
        this.txtCedula.setText(null);
        this.txtNombre.setText(null);
        this.txtApellido.setText(null);
        this.txtContraseña.setText(null);
        this.txtUsername.setText(null);
        this.cmbTipo.getSelectionModel().select(-1);
        this.cmbGenero.getSelectionModel().select(-1);
        this.txtCedula.requestFocus();
    }
    
    public void setGestionUsuariosController(GestionUsuariosController gestionUsuariosController) {
        this.gestionUsuariosController = gestionUsuariosController;
    }
}
