/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Validaciones;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.StackPane;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import javafx.scene.control.Alert;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class BuscarDatosController implements Initializable {

    @FXML private StackPane rootPane;
    @FXML private TextField txtCedula;
    private final listaDeClientes CLIENTES = new listaDeClientes();
    private Validaciones validar= new Validaciones();
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
    }
    
    @FXML
    private void clickBtnBuscar(){
        
        if(validar.numero(this.txtCedula.getText())==1){
                Alert alert = new Alert(Alert.AlertType.ERROR);
                alert.setTitle("Error");
                alert.setHeaderText("Cedula no valida");
                alert.show();
            
        }else{
            
            long cedula = Long.parseLong(this.txtCedula.getText());
            Cliente cliente = this.CLIENTES.buscarCliente(cedula);
            System.out.println(cliente.toString());
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtCedula.setText(null);
        this.txtCedula.requestFocus();
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
}
