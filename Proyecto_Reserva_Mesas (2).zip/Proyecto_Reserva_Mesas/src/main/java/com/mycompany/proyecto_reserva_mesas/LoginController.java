package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.logica.listaDeUsuarios;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

public class LoginController implements Initializable {

    @FXML private Button btnLogin;
    @FXML private TextField txtUsername;
    @FXML private PasswordField txtPassword;
    private listaDeUsuarios usuarios = new listaDeUsuarios();

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }   
    
    @FXML private void clickBtnLogin() throws IOException {
        String username = this.txtUsername.getText();
        String password = this.txtPassword.getText();
        if(this.usuarios.login(username, password)){
            App.setStage("home");
        }else{
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Mensaje de Login");
            alert.setHeaderText("Informacion de credenciales registradas");
            alert.setContentText("Las credenciales registradas no son correctas, "
                    + "intente nuevamente");
            alert.show();
        }
    }
}
