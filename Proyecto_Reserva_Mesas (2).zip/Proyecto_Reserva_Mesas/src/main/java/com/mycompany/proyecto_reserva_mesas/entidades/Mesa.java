/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;

/**
 *
 * @author Fabian Hinojosa
 */
public class Mesa implements Serializable{
    private static final long serialVersionUID = -201366605073525599L;
    private int numeroMesa;
    private int numeroDeAsientos;
    private String estado;
    private Sala ubicacionSala;
    
    public Mesa(){
        this.estado = "Libre";
    }

    public Mesa(int numeroMesa, int numeroDeAsientos) {
        this.numeroMesa = numeroMesa;
        this.numeroDeAsientos = numeroDeAsientos;
        
    }

    public int getNumero() {
        return numeroMesa;
    }

    public void setNumeroMesa(int numeroMesa) {
        this.numeroMesa = numeroMesa;
    }

    public int getNumeroDeAsientos() {
        return numeroDeAsientos;
    }

    public void setNumeroDeAsientos(int numeroDeAsientos) {
        this.numeroDeAsientos = numeroDeAsientos;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
    
    public String definirEstado() {
        return estado;
    }
    
    public Sala getUbicacionSala() {
        return ubicacionSala;
    }

    public void setUbicacionSala(Sala ubicacionSala) {
        this.ubicacionSala = ubicacionSala;
    }

    @Override
    public String toString() {
        return "numeroMesa: " + numeroMesa + ", numeroDeAsientos: " + numeroDeAsientos + ", estado: " + estado + ", ubicacionSala: " + ubicacionSala;
    }
    
    public String dataToFile(){
        return this.numeroMesa +";"+ this.numeroDeAsientos +";"+ this.estado +";"+ this.ubicacionSala;
    }
}