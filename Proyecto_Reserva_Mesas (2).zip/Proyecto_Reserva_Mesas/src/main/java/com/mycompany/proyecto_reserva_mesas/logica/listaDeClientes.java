/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.logica;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import java.util.List;
import com.mycompany.proyecto_reserva_mesas.persistencia.ICrudRegistroCliente;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroClientesArchivoObjeto;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroClientesImpArrayList;

/**
 *
 * @author Fabian Hinojosa
 */
public class listaDeClientes{
    //private List<Cliente> listaClientes;
    private ICrudRegistroCliente persistencia;
    
    public listaDeClientes(){
        this.persistencia = new RegistroClientesArchivoObjeto();
    }
    
    public boolean añadirCliente(Cliente cliente){
        return this.persistencia.aniadirCliente(cliente);
    }
    
    public boolean eliminarCliente(long cedula) {
        return this.persistencia.eliminarCliente(cedula);
    }
    
    public Cliente buscarCliente(long cedula){
        return this.persistencia.buscarCliente(cedula);
    }
    
    public List<Cliente> getClientes(){
        return this.persistencia.obtenerDatos();
    }
}
