/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.logica;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import java.util.List;
import com.mycompany.proyecto_reserva_mesas.persistencia.ICrudRegistroSala;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroSalasArchivoObjeto;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroSalasImpArrayList;

/**
 *
 * @author Fabian Hinojosa
 */
public class listaDeSalas {
    //private List<Sala> listaSalas;
    private ICrudRegistroSala persistencia;
    
    public listaDeSalas(){
        this.persistencia = new RegistroSalasArchivoObjeto();
    }

    public ICrudRegistroSala getPersistencia() {
        return persistencia;
    }

    public void setPersistencia(ICrudRegistroSala persistencia) {
        this.persistencia = persistencia;
    }
    
    public boolean crearSala(int numSala, String descSala){
        Sala s = new Sala(numSala, descSala);
        return this.persistencia.crearSala(s);
    }
    
    public Sala buscarSala(int salaBuscar){
        return this.persistencia.buscarSala(salaBuscar);
    }
    
    public boolean eliminarSala(int salaEliminar){
        return this.persistencia.eliminarSala(salaEliminar);
    } 
    
    public List<Sala> getSala(){
        return this.persistencia.getSalas();
    }
}
