/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.net.URL;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeReservas;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class ReservarController implements Initializable {
    
    @FXML private TextField txtCedulaCliente;
    @FXML private TextField txtIdMesa;
    @FXML private TextField txtFecha;
    @FXML private TextField txtHora;
    @FXML private StackPane rootPane;
    @FXML private TextField txtCodigo;
    @FXML private TextField txtEstado;
    private listaDeClientes clientes = new listaDeClientes();
    private listaDeMesas mesas = new listaDeMesas();
    private listaDeReservas reservas = new listaDeReservas();
    private GestionReservaController gestionReservaController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    } 
    
    @FXML 
    private void clickBtnConfirmar(){
        long cedula = Long.parseLong(this.txtCedulaCliente.getText());
        int m = Integer.parseInt(this.txtIdMesa.getText());
        String codigo = this.txtCodigo.getText();
        String fecha = this.txtFecha.getText();
        String estado = this.txtEstado.getText();
        String h = this.txtHora.getText();
        String[] fec = fecha.split("/");
        String[] ho = h.split(":");
        int dia = Integer.parseInt(fec[0]);
        int mes = Integer.parseInt(fec[1]);
        int año = Integer.parseInt(fec[2]);
        int hora = Integer.parseInt(ho[0]);
        int minuto = Integer.parseInt(ho[1]);
        Reserva reserva = new Reserva(codigo, this.clientes.buscarCliente(cedula), 
                LocalDate.of(año, mes, dia), LocalTime.of(hora, minuto), this.mesas.buscarMesa(m), "Activa");
        this.reservas.crearReserva(reserva);
        
        for(Mesa mesa : this.mesas.getMesas()){
            if(mesa.getNumero() == m){
                mesa.setEstado("Reservada");
                this.mesas.editarMesa(mesa, "Reservada");
                break;
            }
        }
        
        if (gestionReservaController != null) {
            gestionReservaController.actualizarTabla();
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtCedulaCliente.setText(null);
        this.txtFecha.setText(null);
        this.txtHora.setText(null);
        this.txtIdMesa.setText(null);
        this.txtCedulaCliente.requestFocus();
        this.txtIdMesa.requestFocus();
        this.txtFecha.requestFocus();
        this.txtHora.requestFocus();
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void setGestionReservaController(GestionReservaController gestionReservaController) {
        this.gestionReservaController = gestionReservaController;
    }
}
