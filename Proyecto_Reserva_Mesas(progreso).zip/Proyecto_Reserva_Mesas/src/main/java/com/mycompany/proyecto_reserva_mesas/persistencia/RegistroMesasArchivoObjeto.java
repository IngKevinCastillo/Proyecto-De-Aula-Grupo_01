/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public class RegistroMesasArchivoObjeto implements ICrudRegistroMesa{
    private File archivo;
    private FileOutputStream aEscritura;
    private FileInputStream aLectura;

    public RegistroMesasArchivoObjeto(String name) {
        this.archivo = new File(name);
        crearArchivoSiNoExiste();
    }

    public RegistroMesasArchivoObjeto() {
        this("mesas.obj");
    }

    private void crearArchivoSiNoExiste() {
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo.");
        }
    }

    private ICrudRegistroMesa leer() {
        ICrudRegistroMesa coleccion = null;
        if (!this.archivo.exists() || this.archivo.length() == 0) {
            return new RegistroMesasImpArrayList();
        }
        ObjectInputStream ois = null;
        try {
            this.aLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.aLectura);
            coleccion = (ICrudRegistroMesa) ois.readObject();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de lectura.");
        } catch (InvalidClassException ex) {
            System.out.println("Incompatibilidad de versión: " + ex.getMessage());
            coleccion = new RegistroMesasImpArrayList(); // Crear nueva instancia si hay incompatibilidad
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de lectura: ");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al leer objeto.");
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectInputStream.");
                }
            }
        }
        return coleccion;
    }

    private void guardar(ICrudRegistroMesa coleccion) {
        ObjectOutputStream oos = null;
        try {
            this.aEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.aEscritura);
            oos.writeObject(coleccion);
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de escritura.");
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de escritura.");
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectOutputStream.");
                }
            }
        }
    }
    
    @Override
    public boolean crearMesa(Mesa mesa) {
        ICrudRegistroMesa coleccion = this.leer();
        coleccion.crearMesa(mesa);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public Mesa buscarMesa(int numMesa) {
        ICrudRegistroMesa coleccion = this.leer();
        return coleccion.buscarMesa(numMesa);
    }

    @Override
    public void agregarMesaASala(int numSala, int numMesa) {
        ICrudRegistroMesa coleccion = this.leer();
        coleccion.agregarMesaASala(numSala, numMesa);
        this.guardar(coleccion);
    }

    @Override
    public List<Mesa> getMesas() {
        ICrudRegistroMesa coleccion = this.leer();
        return coleccion.getMesas();
    }

    @Override
    public boolean eliminarMesa(int id) {
        ICrudRegistroMesa coleccion = this.leer();
        coleccion.eliminarMesa(id);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean editarMesa(Mesa mesa, String estado) {
        ICrudRegistroMesa coleccion = this.leer();
        Mesa buscada = coleccion.buscarMesa(mesa.getNumero());
        buscada.setEstado(estado);
        this.guardar(coleccion);
        return true;
    }
    
}
