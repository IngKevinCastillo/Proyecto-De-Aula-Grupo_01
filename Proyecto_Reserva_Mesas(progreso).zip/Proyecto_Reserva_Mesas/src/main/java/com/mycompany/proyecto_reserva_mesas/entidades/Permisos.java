/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;

/**
 *
 * @author Fabian Hinojosa
 */
public class Permisos implements Serializable{
    private static final long serialVersionUID = 1L;
    private boolean gestionReserv;
    private boolean gestionUsuario;
    private boolean gestionCliente;
    private boolean gestionMesas;
    private boolean gestionSalas;

    public boolean isGestionReserv() {
        return gestionReserv;
    }

    public Permisos() {
        this.gestionReserv = false;
        this.gestionUsuario = false;
        this.gestionCliente = false;
        this.gestionMesas = false;
        this.gestionSalas = false;
    }

    public void setGestionReserv(boolean gestionReserv) {
        this.gestionReserv = gestionReserv;
    }

    

    public boolean isGestionUsuario() {
        return gestionUsuario;
    }

    public void setGestionUsuario(boolean gestionUsuario) {
        this.gestionUsuario = gestionUsuario;
    }

    public boolean isGestionCliente() {
        return gestionCliente;
    }

    public void setGestionCliente(boolean gestionCliente) {
        this.gestionCliente = gestionCliente;
    }

    public boolean isGestionMesas() {
        return gestionMesas;
    }

    public void setGestionMesas(boolean gestionMesas) {
        this.gestionMesas = gestionMesas;
    }

    public boolean isGestionSalas() {
        return gestionSalas;
    }

    public void setGestionSalas(boolean gestionSalas) {
        this.gestionSalas = gestionSalas;
    }
}
