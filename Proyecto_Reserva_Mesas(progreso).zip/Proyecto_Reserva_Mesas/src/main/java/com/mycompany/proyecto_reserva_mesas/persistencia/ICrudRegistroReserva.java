/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.*;

/**
 *
 * @author Fabian Hinojosa
 */
public interface ICrudRegistroReserva extends Serializable{
    
    boolean crearReserva(Reserva reserva);
    boolean eliminarReserva(String codigo);
    boolean ocuparMesa(Reserva reserva);
    boolean desocuparMesa(String codigo);
    Reserva buscarReserva(String codigo);
    List<Reserva> obtenerReservas();
}
