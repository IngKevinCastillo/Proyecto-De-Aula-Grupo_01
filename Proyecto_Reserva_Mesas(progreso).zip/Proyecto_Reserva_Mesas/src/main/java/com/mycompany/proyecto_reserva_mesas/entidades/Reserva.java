package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;


/**
 *
 * @author Fabian Hinojosa
 */
public class Reserva implements Serializable {
    private static final long serialVersionUID = 4070971119935876757L;
    private String codReserva;
    private Cliente cliente;
    private LocalDate fechaDeReserva;
    private LocalTime HoraDeReserva;
    private Mesa mesaReservar;
    private String estadoReserva;

    public Reserva(){
        super();
    }
    
    public Reserva(String codReserva, Cliente cliente, LocalDate fechaDeReserva, LocalTime HoraDeReserva, Mesa mesaReservar, String estadoReserva) {
        this.codReserva = codReserva;
        this.cliente = cliente;
        this.fechaDeReserva = fechaDeReserva;
        this.HoraDeReserva = HoraDeReserva;
        this.mesaReservar = mesaReservar;
        this.estadoReserva = estadoReserva;
    }
    
    public String getCodReserva() {
        return codReserva;
    }

    public void setCodReserva(String codReserva) {
        this.codReserva = codReserva;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        this.cliente = cliente;
    }

    public Mesa getMesaReservar() {
        return mesaReservar;
    }

    public void setMesaReservar(Mesa mesaReservar) {
        this.mesaReservar = mesaReservar;
    }
    
    public LocalDate getFechaDeReserva() {
        return fechaDeReserva;
    }

    public void setFechaDeReserva(LocalDate fechaDeReserva) {
        this.fechaDeReserva = fechaDeReserva;
    }

    public LocalTime getHoraDeReserva() {
        return HoraDeReserva;
    }

    public void setHoraDeReserva(LocalTime HoraDeReserva) {
        this.HoraDeReserva = HoraDeReserva;
    }
    
    public String getEstadoReserva() {
        return estadoReserva;
    }

    public void setEstadoReserva(String estadoReserva) {
        this.estadoReserva = estadoReserva;
    }
    
    /*public void ocuparMesa(Cliente cliente, Mesa mesa) {
        if (mesa.definirEstado() == true) {
            System.out.println("La mesa " + mesa.getNumero() + " está ocupada.");
        } else {
            mesa.setEstado(true);
            this.mesaReservar = mesa;
            this.fechaDeReserva = LocalDate.now();
            this.HoraDeReserva = LocalTime.now();
            System.out.println("La mesa " + mesa.getNumero() + " ha sido ocupada.");
        }
    }
 
    public void reservarMesa(Cliente cliente, Mesa mesa, LocalDate fecha, LocalTime hora) {
        if (mesa.definirEstado() == true) {
            System.out.println("La mesa " + mesa.getNumero() + " está ocupada, no se puede reservar.");
        } else {
            mesa.setEstado(true);
            setEstadoReserva(true);
            this.mesaReservar = mesa;
            this.fechaDeReserva = fecha;
            this.HoraDeReserva = hora;
            System.out.println("Mesa " + mesa.getNumero() + " reservada.");
        }
    }
    
    public void eliminarReserva(Mesa mesa){
        if(mesa.definirEstado() == false){
            if(estadoReserva == false){
                System.out.println("La mesa " + mesa.getNumero() + " no está reservada ni ocupada.");
            }
        }else{
            mesa.setEstado(false);
            setEstadoReserva(false);
            this.setMesaReservar(null);
            System.out.println("La mesa " + mesa.getNumero() + " ahora esta disponible.");
        }
    }
    
    public void desocuparMesa(Mesa mesa){
        if(mesa.definirEstado() == false){
            System.out.println("La mesa " + mesa.getNumero() + " está desocupada.");
        }else{
            mesa.setEstado(false);
            System.out.println("La mesa " + mesa.getNumero() + " ha sido desocupada.");
        }
    }*/

    @Override
    public String toString() {
        return "Cliente: " + this.cliente.getCedula()
                + ", codigo: " + this.codReserva
                + ", fecha De Reservacion: " + this.fechaDeReserva 
                + ", hora De Reservacion: " + this.HoraDeReserva 
                + ", Mesa: " + this.mesaReservar.getNumero()
                + ", estado de Reserva: " + this.estadoReserva;
    }

    public String dataToFile(){
        return this.cliente.getCedula() +";"+ this.codReserva +";"+ this.fechaDeReserva +";"+ this.HoraDeReserva +";"+ this.mesaReservar +";"+ this.estadoReserva;
    }
}