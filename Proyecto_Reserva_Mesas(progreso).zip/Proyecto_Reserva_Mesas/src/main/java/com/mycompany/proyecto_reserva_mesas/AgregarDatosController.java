package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

public class AgregarDatosController implements Initializable {

    @FXML private Button btnSalir;
    @FXML private StackPane rootPane;
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellido;
    @FXML private TextField txtCedula;
    @FXML private TextField txtTelefono;
    @FXML private TextField txtCorreo;
    @FXML private ComboBox<String> cmbGenero;
    private listaDeClientes clientes = new listaDeClientes();
    private GestionClientesController gestionClientesController;

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        this.cmbGenero.getItems().addAll("Masculino", "Femenino");
    }

    @FXML
    private void clickBtnGuardar() {
        if (validarCampos()) {
            try {
                long telefono = Long.parseLong(this.txtTelefono.getText());
                String nombre = this.txtNombre.getText();
                String apellido = this.txtApellido.getText();
                long cedula = Long.parseLong(this.txtCedula.getText());
                String correo = this.txtCorreo.getText();
                String genero = this.cmbGenero.getSelectionModel().getSelectedItem().toString();
                
                Cliente c = new Cliente(telefono, nombre, apellido, cedula, genero, correo);
                this.clientes.añadirCliente(c);
                System.out.println(this.clientes.getClientes().size() + " registrados");
                
                if (gestionClientesController != null) {
                    gestionClientesController.actualizarTabla();
                }
            } catch (NumberFormatException e) {
                mostrarAlerta("Error", "Formato inválido", "Por favor ingrese números válidos para teléfono y cédula.");
            }
        } else {
            mostrarAlerta("Error", "Campos inválidos", "Revise que todos los campos estén llenos y sean correctos.");
        }
    }

    @FXML
    private void clickBtnSalir() {
        this.limpiar();
        this.closeWindow();
    }

    private void closeWindow() {
        rootPane.setVisible(false);
    }

    public void limpiar() {
        this.txtApellido.setText(null);
        this.txtCedula.setText(null);
        this.txtCorreo.setText(null);
        this.txtNombre.setText(null);
        this.txtTelefono.setText(null);
        this.txtCedula.requestFocus();
        this.txtTelefono.requestFocus();
    }

    public void setGestionClientesController(GestionClientesController gestionClientesController) {
        this.gestionClientesController = gestionClientesController;
    }
    
    private boolean validarCampos() {
        String nombre = this.txtNombre.getText();
        String apellido = this.txtApellido.getText();
        String cedulaStr = this.txtCedula.getText();
        String telefonoStr = this.txtTelefono.getText();
        
        if (nombre.isEmpty() || apellido.isEmpty() || cedulaStr.isEmpty() || telefonoStr.isEmpty()) {
            return false;
        }
        
        if (!nombre.matches("[a-zA-Z]+") || !apellido.matches("[a-zA-Z]+")) {
            return false;
        }
        
        try {
            long cedula = Long.parseLong(cedulaStr);
            long telefono = Long.parseLong(telefonoStr);
            if (cedula < 1000000 || cedula > 9999999999L) {
                return false;
            }
            if (telefono < 1000000 || telefono > 9999999999L) {
                return false;
            }
        } catch (NumberFormatException e) {
            return false;
        }
        
        return true;
    }
    
    private void mostrarAlerta(String titulo, String encabezado, String contenido) {
        Alert alert = new Alert(AlertType.ERROR);
        alert.setTitle(titulo);
        alert.setHeaderText(encabezado);
        alert.setContentText(contenido);
        alert.showAndWait();
    }
}
