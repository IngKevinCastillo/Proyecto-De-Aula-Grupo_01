/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public class RegistroUsuariosArchivoObjeto implements ICrudRegistroUsuarios{
    private File archivo;
    private FileOutputStream aEscritura;
    private FileInputStream aLectura;

    public RegistroUsuariosArchivoObjeto(String name) {
        this.archivo = new File(name);
        crearArchivoSiNoExiste();
    }

    public RegistroUsuariosArchivoObjeto() {
        this("usuarios.obj");
    }

    private void crearArchivoSiNoExiste() {
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo.");
        }
    }

    private ICrudRegistroUsuarios leer() {
        ICrudRegistroUsuarios coleccion = null;
        if (!this.archivo.exists() || this.archivo.length() == 0) {
            return new RegistroUsuariosImpArrayList();
        }
        ObjectInputStream ois = null;
        try {
            this.aLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.aLectura);
            coleccion = (ICrudRegistroUsuarios) ois.readObject();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de lectura.");
        } catch (InvalidClassException ex) {
            System.out.println("Incompatibilidad de versión: " + ex.getMessage());
            coleccion = new RegistroUsuariosImpArrayList(); // Crear nueva instancia si hay incompatibilidad
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de lectura: " + ex.getMessage());
            coleccion = new RegistroUsuariosImpArrayList(); // Crear nueva instancia en caso de error
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al leer objeto.");
            coleccion = new RegistroUsuariosImpArrayList(); // Crear nueva instancia en caso de error
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectInputStream.");
                }
            }
            if (this.aLectura != null) {
                try {
                    this.aLectura.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar FileInputStream.");
                }
            }
        }
        return coleccion != null ? coleccion : new RegistroUsuariosImpArrayList();
    }

    
    private void guardar(ICrudRegistroUsuarios coleccion) {
        ObjectOutputStream oos = null;
        try {
            this.aEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.aEscritura);
            oos.writeObject(coleccion);
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de escritura.");
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de escritura.");
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectOutputStream.");
                }
            }
            if (this.aEscritura != null) {
                try {
                    this.aEscritura.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar FileOutputStream.");
                }
            }
        }
    }
    
    @Override
    public boolean añadirUsuario(Usuario nuevo) {
        ICrudRegistroUsuarios coleccion = this.leer();
        coleccion.añadirUsuario(nuevo);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean eliminarUsuario(String empleado) {
        ICrudRegistroUsuarios coleccion = this.leer();
        coleccion.eliminarUsuario(empleado);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public Usuario buscarUsuario(String username) {
        ICrudRegistroUsuarios coleccion = this.leer();
        return coleccion.buscarUsuario(username);
    }

    @Override
    public List<Usuario> obtenerDatos() {
        ICrudRegistroUsuarios coleccion = this.leer();
        return coleccion.obtenerDatos();
    }

    @Override
    public String cambiarContrasenia(String username, String contrasenia) {
        ICrudRegistroUsuarios coleccion = this.leer();
        coleccion.cambiarContrasenia(username, contrasenia);
        this.guardar(coleccion);
        return "Contraseña Cambiada";
    }
    
}
