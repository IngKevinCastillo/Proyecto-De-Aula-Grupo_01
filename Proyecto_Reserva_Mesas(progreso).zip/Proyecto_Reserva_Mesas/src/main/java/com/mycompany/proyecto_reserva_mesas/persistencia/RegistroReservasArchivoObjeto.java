package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InvalidClassException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;

public class RegistroReservasArchivoObjeto implements ICrudRegistroReserva {
    private File archivo;
    private FileOutputStream aEscritura;
    private FileInputStream aLectura;

    public RegistroReservasArchivoObjeto(String name) {
        this.archivo = new File(name);
        crearArchivoSiNoExiste();
    }

    public RegistroReservasArchivoObjeto() {
        this("reservas.obj");
    }

    private void crearArchivoSiNoExiste() {
        try {
            if (!archivo.exists()) {
                archivo.createNewFile();
            }
        } catch (IOException ex) {
            System.out.println("Error al crear el archivo.");
        }
    }

    private ICrudRegistroReserva leer() {
        ICrudRegistroReserva coleccion = null;
        if (!this.archivo.exists() || this.archivo.length() == 0) {
            return new RegistroReservaImpArrayList();
        }
        ObjectInputStream ois = null;
        try {
            this.aLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.aLectura);
            coleccion = (ICrudRegistroReserva) ois.readObject();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de lectura.");
        } catch (InvalidClassException ex) {
            System.out.println("Incompatibilidad de versión: " + ex.getMessage());
            coleccion = new RegistroReservaImpArrayList(); // Crear nueva instancia si hay incompatibilidad
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de lectura: " + ex.getMessage());
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al leer objeto.");
        } finally {
            if (ois != null) {
                try {
                    ois.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectInputStream.");
                }
            }
            if (this.aLectura != null) {
                try {
                    this.aLectura.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar FileInputStream.");
                }
            }
        }
        return coleccion;
    }
    
    private void guardar(ICrudRegistroReserva coleccion) {
        ObjectOutputStream oos = null;
        try {
            this.aEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.aEscritura);
            oos.writeObject(coleccion);
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir archivo de escritura.");
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de escritura.");
        } finally {
            if (oos != null) {
                try {
                    oos.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar ObjectOutputStream.");
                }
            }
            if (this.aEscritura != null) {
                try {
                    this.aEscritura.close();
                } catch (IOException ex) {
                    System.out.println("Error al cerrar FileOutputStream.");
                }
            }
        }
    }


    @Override
    public boolean crearReserva(Reserva reserva) {
        ICrudRegistroReserva coleccion = this.leer();
        coleccion.crearReserva(reserva);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean eliminarReserva(String codigo) {
        ICrudRegistroReserva coleccion = this.leer();
        coleccion.eliminarReserva(codigo);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean ocuparMesa(Reserva reserva) {
        ICrudRegistroReserva coleccion = this.leer();
        coleccion.ocuparMesa(reserva);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean desocuparMesa(String codigo) {
        ICrudRegistroReserva coleccion = this.leer();
        coleccion.desocuparMesa(codigo);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public Reserva buscarReserva(String codigoReserva) {
        ICrudRegistroReserva coleccion = this.leer();
        return coleccion.buscarReserva(codigoReserva);
    }

    @Override
    public List<Reserva> obtenerReservas() {
        ICrudRegistroReserva coleccion = this.leer();
        return coleccion.obtenerReservas();
    }
}
