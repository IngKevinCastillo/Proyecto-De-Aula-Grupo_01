package com.mycompany.proyecto_reserva_mesas;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import static javafx.application.Application.launch;
import javafx.scene.Node;
import javafx.stage.Window;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;
    private static Stage primaryStage;

    @Override
    public void start(Stage stage) throws IOException {
        primaryStage = stage;
        scene = new Scene(loadFXML("login"));
        stage.setScene(scene);
        stage.setMaximized(true);
        stage.show();
    }

    // Reemplaza una stage por otra
    public static void setStage(String fxml) throws IOException {
        Window ventana = scene.getWindow();
        Stage stage = (Stage) ventana;

        Stage nuevaStage = new Stage();
        scene = new Scene(loadFXML(fxml));
        nuevaStage.setScene(scene);
        nuevaStage.setMaximized(true);
        stage.hide();
        nuevaStage.show();
    }

    // Crea una nueva escena y la establece como escena de la Stage principal
    public static void setNewScene(String fxml) throws IOException {
        Window ventana = scene.getWindow();
        Stage stage = (Stage) ventana;
        setRoot(fxml);
        stage.setMaximized(true);
    }

    // Lee un componente a partir de un archivo FXML y lo retorna como nodo
    public static Node loadComponent(String fxml) throws IOException {
        return (Node) loadFXML(fxml);
    }

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    static Parent loadFXML(String fxml) throws IOException {
        FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource(fxml + ".fxml"));
        return fxmlLoader.load();
    }

    // Método para cerrar la ventana principal
    public static void closePrimaryStage() {
        primaryStage.close();
    }

    /*Método para reabrir la ventana principal
    public static void reopenPrimaryStage() {
        primaryStage.show();
    }*/

    public static void main(String[] args) {
        launch();
    }
}
