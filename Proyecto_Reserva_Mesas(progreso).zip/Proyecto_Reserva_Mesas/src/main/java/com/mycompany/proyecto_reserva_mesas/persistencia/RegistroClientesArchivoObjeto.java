package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.List;

public class RegistroClientesArchivoObjeto implements ICrudRegistroCliente {
    private File archivo;
    private FileOutputStream aEscritura;
    private FileInputStream aLectura;

    public RegistroClientesArchivoObjeto(String name) {
        this.archivo = new File(name);
    }

    public RegistroClientesArchivoObjeto() {
        this("clientes.obj");
    }

    private ICrudRegistroCliente leer() {
        ICrudRegistroCliente coleccion = null;
        if (!this.archivo.exists()) {
            return new RegistroClientesImpArrayList();
        }
        ObjectInputStream ois = null;
        try {
            this.aLectura = new FileInputStream(this.archivo);
            ois = new ObjectInputStream(this.aLectura);
            coleccion = (ICrudRegistroCliente) ois.readObject();
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir o crear archivo de lectura.");
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de lectura.");
        } catch (ClassNotFoundException ex) {
            System.out.println("Error al leer objeto.");
        }
        return coleccion;
    }

    private void guardar(ICrudRegistroCliente coleccion) {
        ObjectOutputStream oos = null;
        try {
            this.aEscritura = new FileOutputStream(this.archivo);
            oos = new ObjectOutputStream(this.aEscritura);
            oos.writeObject(coleccion);
        } catch (FileNotFoundException ex) {
            System.out.println("Error al abrir o crear archivo de escritura.");
        } catch (IOException ex) {
            System.out.println("Error al crear objeto de escritura.");
        }
    }

    @Override
    public boolean aniadirCliente(Cliente nuevoCliente) {
        ICrudRegistroCliente coleccion = this.leer();
        coleccion.aniadirCliente(nuevoCliente);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public boolean eliminarCliente(long cedula) {
        ICrudRegistroCliente coleccion = this.leer();
        coleccion.eliminarCliente(cedula);
        this.guardar(coleccion);
        return true;
    }

    @Override
    public Cliente buscarCliente(long cedula) {
        ICrudRegistroCliente coleccion = this.leer();
        return coleccion.buscarCliente(cedula);
    }

    @Override
    public List<Cliente> obtenerDatos() {
        ICrudRegistroCliente coleccion = this.leer();
        return coleccion.obtenerDatos();
    }
}
