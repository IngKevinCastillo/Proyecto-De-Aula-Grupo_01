/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeSalas;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class EliminarSalaController implements Initializable {
    
    @FXML private StackPane rootPane;
    @FXML private TextField txtId;
    private final listaDeSalas SALA = new listaDeSalas();
    private GestionSalasController gestionSalasController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    private void clickBtnConfirmar(){
        int numSala = Integer.parseInt(this.txtId.getText());
        this.SALA.eliminarSala(numSala);
        
        if (gestionSalasController != null) {
            gestionSalasController.actualizarTabla();
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtId.setText(null);
        this.txtId.requestFocus();
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void setGestionClientesController(GestionSalasController gestionSalasController) {
        this.gestionSalasController = gestionSalasController;
    } 
}
