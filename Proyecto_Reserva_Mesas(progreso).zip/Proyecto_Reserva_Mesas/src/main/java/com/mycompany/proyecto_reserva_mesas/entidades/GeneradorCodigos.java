package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.IOException;
import java.io.Serializable;
import java.time.*;
import java.time.format.DateTimeFormatter;
import java.util.Random;

public class GeneradorCodigos implements Serializable {
    private static final long serialVersionUID = 1L;  // Agrega serialVersionUID para mantener consistencia en la serialización

    private transient LocalDate fechaActual;  // Transient para no serializar este campo
    private transient DateTimeFormatter formatter;  // Transient para no serializar este campo

    public GeneradorCodigos() {
        this.fechaActual = LocalDate.now();
        this.formatter = DateTimeFormatter.ofPattern("MMM");
    }

    private String generarLetrasAleatorias(int length) {
        Random random = new Random();
        StringBuilder letras = new StringBuilder();
        while (letras.length() < length) {
            char letra = (char) ('A' + random.nextInt(26));
            if (letras.indexOf(String.valueOf(letra)) == -1) {
                letras.append(letra);
            }
        }
        return letras.toString();
    }

    public String generarCodigo(String palabraFija) {
        this.fechaActual = LocalDate.now();
        String mes = fechaActual.format(formatter).toUpperCase();
        int dia = fechaActual.getDayOfMonth();
        String diaStr = (dia < 10) ? "0" + dia : String.valueOf(dia);
        String letrasAleatorias = generarLetrasAleatorias(3);
        String codigoFinal = mes + palabraFija + diaStr + letrasAleatorias;
        return codigoFinal;
    }
    
    // Método readObject para inicializar los campos transient después de la deserialización
    private void readObject(java.io.ObjectInputStream in) 
        throws IOException, ClassNotFoundException {
        in.defaultReadObject();
        this.fechaActual = LocalDate.now();
        this.formatter = DateTimeFormatter.ofPattern("MMM");
    }
}
