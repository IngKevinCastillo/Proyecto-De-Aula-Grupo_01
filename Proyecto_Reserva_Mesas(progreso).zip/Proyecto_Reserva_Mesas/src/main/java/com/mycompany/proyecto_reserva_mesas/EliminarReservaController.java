/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.net.URL;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeReservas;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class EliminarReservaController implements Initializable {
    
    @FXML private TextField txtCodigo;
    @FXML private StackPane rootPane;
    private listaDeReservas reservas = new listaDeReservas();
    private listaDeMesas mesas = new listaDeMesas();
    private GestionReservaController gestionReservaController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    private void clickBtnConfirmar(){
        String codigo = this.txtCodigo.getText();
        
        for(Reserva c :  this.reservas.obtenerReservas()){
            if(c.getCodReserva().equals(codigo)){
                 Mesa mesa = c.getMesaReservar();
                for(Mesa m : this.mesas.getMesas()){
                    if(m.getNumero() == mesa.getNumero()){
                        m.setEstado("Libre");
                        this.mesas.editarMesa(m, "Libre");
                        this.reservas.eliminarReserva(codigo);
                        break;
                    }
                }      
            }
        }
        
        if (gestionReservaController != null) {
            gestionReservaController.actualizarTabla();
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtCodigo.setText(null);
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void setGestionReservaController(GestionReservaController gestionReservaController) {
        this.gestionReservaController = gestionReservaController;
    }
}
