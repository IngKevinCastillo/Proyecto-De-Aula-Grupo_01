/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.TextField;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class buscarMesaController implements Initializable {
    
    @FXML private StackPane rootPane;
    @FXML private TextField txtId;
    private listaDeMesas mesas = new listaDeMesas(); 
    private GestionMesasController gestionMesasController;
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }
    
    @FXML
    private void clickBtnConfirmar(){
        int numMesa = Integer.parseInt(this.txtId.getText());
        this.mesas.buscarMesa(numMesa);
        
        if (gestionMesasController != null) {
            gestionMesasController.actualizarTabla();
        }
    }
    
    @FXML
    private void clickBtnSalir(){
        this.limpiar();
        this.closeWindow();
    }
    
    public void limpiar(){
        this.txtId.setText(null);
        this.txtId.requestFocus();
    }
    
    private void closeWindow() {
        rootPane.setVisible(false);
    }
    
    public void setGestionMesasController(GestionMesasController gestionMesasController) {
        this.gestionMesasController = gestionMesasController;
    }
}
