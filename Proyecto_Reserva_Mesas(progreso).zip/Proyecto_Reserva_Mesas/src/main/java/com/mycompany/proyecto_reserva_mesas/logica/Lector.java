/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.logica;

import java.util.InputMismatchException;
import java.util.Scanner;

/**
 *
 * @author Fabian Hinojosa
 */
public class Lector {
    private static Scanner entrada = new Scanner(System.in);
    
    public static int leerInt(String titulo){
        int valor = 0;
        boolean excepcion;
        
        do{
            try {
                System.out.print(titulo);
                valor = entrada.nextInt();
                excepcion = false;
            } catch (InputMismatchException error) {
                System.out.println("\nError: Se requiere un valor numerico.\n");
                entrada.nextLine();
                excepcion = true;
            }
        }while(excepcion);   
        return valor;
    }
    
    public static long leerLong(String titulo){
        long valor = 0;
        boolean excepcion;
        do{
            try{
                System.out.print(titulo);
                valor = entrada.nextLong();
                excepcion = false;
            }catch(InputMismatchException error){
                System.out.println("\nError: Se requiere un valor numerico.\n");
                entrada.nextLine();
                excepcion = true;
            }
        }while(excepcion);
        return valor;
    } 
}
