/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public interface ICrudRegistroMesa extends Serializable{
    
    boolean crearMesa(Mesa mesa);
    Mesa buscarMesa(int numMesa);
    void agregarMesaASala(int numSala, int numMesa);
    boolean eliminarMesa(int id);
    List<Mesa> getMesas();
    boolean editarMesa(Mesa mesa, String estado);
}
