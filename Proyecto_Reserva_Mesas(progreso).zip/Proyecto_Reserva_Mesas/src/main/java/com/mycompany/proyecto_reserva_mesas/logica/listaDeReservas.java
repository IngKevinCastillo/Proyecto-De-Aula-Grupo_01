/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.logica;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import com.mycompany.proyecto_reserva_mesas.persistencia.ICrudRegistroReserva;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroReservaImpArrayList;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroReservasArchivoObjeto;

/**
 *
 * @author Fabian Hinojosa
 */
public class listaDeReservas {
    //private List<Reserva> listaReservas;
    private ICrudRegistroReserva persistencia;
    
    public listaDeReservas(){
        this.persistencia = new RegistroReservasArchivoObjeto();
    }

    public ICrudRegistroReserva getPersistencia() {
        return persistencia;
    }

    public void setPersistencia(ICrudRegistroReserva persistencia) {
        this.persistencia = persistencia;
    }
    
    public boolean ocuparMesa(Reserva ocupar){
        return this.persistencia.ocuparMesa(ocupar);
    }
    
    public boolean desocuparMesa(String codigo){
        return this.persistencia.desocuparMesa(codigo);
    }
    
    public boolean crearReserva(Reserva reserva){
        return this.persistencia.crearReserva(reserva);
    }
    
    public boolean eliminarReserva(String codigo){
        return this.persistencia.eliminarReserva(codigo);
    }
    
    public Reserva buscarReserva(String codigoReserva){
        return this.persistencia.buscarReserva(codigoReserva);
    }
    
    public List<Reserva> obtenerReservas(){
        return this.persistencia.obtenerReservas();
    }
}
