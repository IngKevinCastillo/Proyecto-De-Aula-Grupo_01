/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Reserva;
import com.mycompany.proyecto_reserva_mesas.entidades.GeneradorCodigos;
import java.io.IOException;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public class RegistroReservaImpArrayList implements Serializable, ICrudRegistroReserva{
    private static final long serialVersionUID = 1L;  // Agrega serialVersionUID para mantener consistencia en la serialización
    private List<Reserva> listaReservas;
    
    public RegistroReservaImpArrayList(){
        this.listaReservas = new ArrayList();
    }

    public List<Reserva> getListaReservas() {
        return listaReservas;
    }

    public void setListaReservas(List<Reserva> listaReservas) {
        this.listaReservas = listaReservas;
    }

    @Override
    public boolean ocuparMesa(Reserva reserva) {
        return this.listaReservas.add(reserva);
    }

    @Override
    public boolean desocuparMesa(String codigo) {
        for(Reserva r : this.listaReservas){
            if(r.getCodReserva().equals(codigo)){
                this.listaReservas.remove(r);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean crearReserva(Reserva reserva) {
        return this.listaReservas.add(reserva);
    }

    @Override
    public boolean eliminarReserva(String codigo) {
        for(Reserva r : this.listaReservas){
            if(r.getCodReserva().equals(codigo)){
                this.listaReservas.remove(r);
                return true;
            }
        }
        return false;
    }

    @Override
    public Reserva buscarReserva(String codigo) {
        for(Reserva r : this.listaReservas){
            if(r.getCodReserva().equals(codigo)){
                return r;
            }
        }
        return null;
    }

    @Override
    public List<Reserva> obtenerReservas() {
        return this.listaReservas;
    }
}