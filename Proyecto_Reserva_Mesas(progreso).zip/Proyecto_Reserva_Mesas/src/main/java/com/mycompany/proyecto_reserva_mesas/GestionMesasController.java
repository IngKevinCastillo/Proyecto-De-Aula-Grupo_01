/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.dto.MesasDto;
import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeMesas;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

/**
 * FXML Controller class
 *
 * @author Fabian Hinojosa
 */
public class GestionMesasController implements Initializable {

    @FXML private TableView tablaMesas;
    @FXML private TableColumn colId;
    @FXML private TableColumn colAsientos;
    @FXML private TableColumn colEstado;
    @FXML private TableColumn colUbicacionSala;
    
    @FXML private StackPane panelOpcionesMesas;
    @FXML private Button btnAñadir;
    @FXML private Button btnBuscar;
    @FXML private Button btnEliminar;
    private ObservableList<MesasDto> listadoMesas;
    private listaDeMesas mesas = new listaDeMesas();
    
    /**
     * Initializes the controller class.
     */
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnAñadir.setOnAction(event -> {
            try{
                cargarPanel("agregarMesas");
            } catch (IOException e) {
            }
        });
        
        btnEliminar.setOnAction(event -> {
            try{
                cargarPanel("eliminarMesa");
            } catch (IOException e) {
            }
        });
        
        btnBuscar.setOnAction(event -> {
            try{
                cargarPanel("buscarMesa");
            } catch (IOException e) {
            }
        });
        
        this.colId.setCellValueFactory(new PropertyValueFactory("id"));
        this.colAsientos.setCellValueFactory(new PropertyValueFactory("asientos"));
        this.colEstado.setCellValueFactory(new PropertyValueFactory("estado"));
        this.colUbicacionSala.setCellValueFactory(new PropertyValueFactory("ubicacionSala"));
        
        this.cargarConsulta();
    }    
    
    private void cargarPanel(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml + ".fxml"));
        StackPane nuevoPanel = loader.load();
        panelOpcionesMesas.getChildren().setAll(nuevoPanel);
        
        if (fxml.equals("agregarMesas")) {
            AgregarMesasController controller = loader.getController();
            controller.setGestionMesasController(this);
        }
        
        if (fxml.equals("eliminarMesa")) {
            EliminarMesaController controller = loader.getController();
            controller.setGestionMesasController(this);
        }
        
        if (fxml.equals("buscarMesa")) {
            buscarMesaController controller = loader.getController();
            controller.setGestionMesasController(this);
        }
    }
    
    public void cargarConsulta(){
        this.listadoMesas = FXCollections.observableArrayList();
        for(Mesa a : this.mesas.getMesas()){
            MesasDto dto = new MesasDto(a);
            this.listadoMesas.add(dto);
        }
        
        this.tablaMesas.setItems(this.listadoMesas);
    }
    
    public void actualizarTabla(){
        this.listadoMesas.clear();
        for(Mesa a : this.mesas.getMesas()){
            MesasDto dto = new MesasDto(a);
            this.listadoMesas.add(dto);
        }
        
        this.tablaMesas.refresh();
    }
}
