/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;


/**
 *
 * @author Fabian Hinojosa
 */
public class Cliente extends Persona implements Serializable {
    private static final long serialVersionUID = 1L;
    private long numTelefono;
    private String correoPer;

    public Cliente() {
    }

    public Cliente(long numTelefono, String nombre, String apellido, long cedula, String genero, String correoPer) {
        super(nombre, apellido, cedula, genero);
        this.numTelefono = numTelefono;
        this.correoPer = correoPer;
    }

    public long getNumTelefono() {
        return numTelefono;
    }

    public void setNumTelefono(long numTelefono) {
        this.numTelefono = numTelefono;
    }
    
    public String getCorreoPer() {
        return correoPer;
    }

    public void setCorreoPer(String correoPer) {
        this.correoPer = correoPer;
    }

    @Override
    public String toString() {
        return "numTelefono: " + super.toString() + numTelefono + ", correoPer: " + getCorreoPer();
    }
    
    public String dataToFile(){
        return this.numTelefono+";"+super.toString()+";"+this.correoPer;
    }
}
