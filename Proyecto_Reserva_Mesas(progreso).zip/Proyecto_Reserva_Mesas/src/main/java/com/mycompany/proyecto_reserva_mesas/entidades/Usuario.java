/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;

/**
 *
 * @author Fabian Hinojosa
 */
public class Usuario extends Persona implements Serializable{
    private static final long serialVersionUID = 1L;
    private String usuario;
    private String contraseña;
    private String tipo;
    Permisos permisos;

    public Usuario() {
    }

    public Usuario(String usuario, String contraseña, String nombre, String apellido, long cedula, String genero) {
        super(nombre, apellido, cedula, genero);
        this.usuario = usuario;
        this.contraseña = contraseña;
    }

    public String getUsuario() {
        return usuario;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public void setUsuario(String usuario) {
        this.usuario = usuario;
    }

    public String getContraseña() {
        return contraseña;
    }

    public void setContraseña(String contraseña) {
        this.contraseña = contraseña;
    }

    public Permisos getPermisos() {
        return permisos;
    }

    public void setPermisos(Permisos permisos) {
        this.permisos = permisos;
    }

    @Override
    public String toString() {
        return super.toString() + ", usuario: " + usuario + ", contraseña: " + contraseña;
    }
    
    
}
