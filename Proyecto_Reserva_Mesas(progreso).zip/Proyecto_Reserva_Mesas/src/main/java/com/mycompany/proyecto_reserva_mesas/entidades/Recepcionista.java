/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.entidades;

import java.io.Serializable;
import java.time.*;
import java.util.*;

/**
 *
 * @author Fabian Hinojosa
 */
public class Recepcionista extends Usuario implements Serializable{
    private ArrayList<Reserva> listaReservas;

    public Recepcionista() {
        listaReservas = new ArrayList<>();
        permisos = new Permisos();
    }

    public Recepcionista(String usuario, String contraseña, String nombre, String apellido, long cedula, String genero) {
        super(usuario, contraseña, nombre, apellido, cedula, genero);
        
        if (permisos == null) {
            permisos = new Permisos();
        }
        
        listaReservas = new ArrayList<>();
        permisos.setGestionReserv(true);
        permisos.setGestionSalas(false);
        permisos.setGestionUsuario(false);
        permisos.setGestionMesas(false);
    }

    public ArrayList<Reserva> getListaReservas() {
        return listaReservas;
    }

    public void setListaReservas(ArrayList<Reserva> listaReservas) {
        this.listaReservas = listaReservas;
    }

    /*public void crearReserva(Cliente cliente, Mesa mesa, LocalDate fecha, LocalTime hora) {
        if(this.permisos.isGestionReserv()==false){
            System.out.println(" Sin acesso al sistema");
        }else{
            Reserva reserva = new Reserva();
            reserva.setCliente(cliente);
            reserva.reservarMesa(cliente, mesa, fecha, hora);
            listaReservas.add(reserva);
        }
    }

    public void quitarReserva(Mesa mesa) {
        if(this.permisos.isGestionReserv()==false){
            System.out.println(" Sin acesso al sistema");
        }else{
        for (Reserva reserva : listaReservas) {
                if (reserva.getMesaReservar().contains(mesa)) {
                    listaReservas.remove(reserva);
                    reserva.eliminarReserva(mesa);
                    return;
                }
            }
        }
    }

    public void ocuparMesaAhora(Cliente cliente, Mesa mesa) {
        if(permisos.isGestionMesas()==false){
            System.out.println(" Sin acesso al sistema");
        }else{
            Reserva reserva = new Reserva();
            reserva.setCliente(cliente);
            reserva.ocuparMesa(cliente, mesa);
            listaReservas.add(reserva);
        }
    }

    public void desocuparMesaAhora(Mesa mesa) {
        if(permisos.isGestionMesas()==false){
            
            System.out.println(" Sin acesso al sistema");
        }else{
            for (Reserva reserva : listaReservas) {
                if (reserva.getMesaReservar().contains(mesa)) {
                    listaReservas.remove(reserva);
                    reserva.desocuparMesa(mesa);
                    break;
                }
            }
        }
    }
    
    public String datosReserva() {
        StringBuilder builder = new StringBuilder("Reservas: \n");
        for (Reserva reserva : listaReservas) {
            builder.append(reserva.toString()).append("\n");
        }
        return builder.toString();
    }*/

    @Override
    public String toString() {
        return super.toString();
    }
    
}