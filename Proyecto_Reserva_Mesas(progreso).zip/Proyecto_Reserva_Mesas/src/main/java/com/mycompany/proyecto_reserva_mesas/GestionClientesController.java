package com.mycompany.proyecto_reserva_mesas;

import com.mycompany.proyecto_reserva_mesas.dto.ClientesDto;
import com.mycompany.proyecto_reserva_mesas.entidades.Cliente;
import com.mycompany.proyecto_reserva_mesas.logica.listaDeClientes;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.StackPane;

public class GestionClientesController implements Initializable {

    @FXML private TableView tablaClientes;
    @FXML private TableColumn colTelefono;
    @FXML private TableColumn colNombre;
    @FXML private TableColumn colApellido;
    @FXML private TableColumn colCedula;
    @FXML private TableColumn colGenero;
    @FXML private TableColumn colCorreo;
    
    @FXML private Button btnAñadir;
    @FXML private Button btnEliminar;
    @FXML private Button btnBuscar;
    @FXML private StackPane panelOpcionesCliente;
    private ObservableList<ClientesDto> listadoClientes;
    private listaDeClientes clientes = new listaDeClientes();
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        btnAñadir.setOnAction(event -> {
            try {
                cargarPanel("agregarDatos");
            } catch (IOException e) {
            }
        });

        btnEliminar.setOnAction(event -> {
            try {
                cargarPanel("eliminarDatos");
            } catch (IOException e) {
            }
        });

        btnBuscar.setOnAction(event -> {
            try {
                cargarPanel("buscarDatos");
            } catch (IOException e) {
            }
        });

        this.colTelefono.setCellValueFactory(new PropertyValueFactory("numTelefono"));
        this.colNombre.setCellValueFactory(new PropertyValueFactory("nombre"));
        this.colApellido.setCellValueFactory(new PropertyValueFactory("apellido"));
        this.colCedula.setCellValueFactory(new PropertyValueFactory("cedula"));
        this.colGenero.setCellValueFactory(new PropertyValueFactory("genero"));
        this.colCorreo.setCellValueFactory(new PropertyValueFactory("correoPer"));

        this.cargarConsulta();
    }


    private void cargarPanel(String fxml) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource(fxml + ".fxml"));
        StackPane nuevoPanel = loader.load();
        panelOpcionesCliente.getChildren().setAll(nuevoPanel);

        if (fxml.equals("agregarDatos")) {
            AgregarDatosController controller = loader.getController();
            controller.setGestionClientesController(this);
        }
        
        if (fxml.equals("eliminarDatos")) {
            EliminarDatosController controller = loader.getController();
            controller.setGestionClientesController(this);
        }
    }
    
    public void cargarConsulta(){
        this.listadoClientes = FXCollections.observableArrayList();
        for(Cliente a : this.clientes.getClientes()){
            ClientesDto dto = new ClientesDto(a);
            this.listadoClientes.add(dto);
        }
        
        this.tablaClientes.setItems(this.listadoClientes);
    }
    
    public void actualizarTabla() {
        this.listadoClientes.clear();
        for (Cliente a : this.clientes.getClientes()) {
            ClientesDto dto = new ClientesDto(a);
            this.listadoClientes.add(dto);
        }
        this.tablaClientes.refresh();
    }
}
