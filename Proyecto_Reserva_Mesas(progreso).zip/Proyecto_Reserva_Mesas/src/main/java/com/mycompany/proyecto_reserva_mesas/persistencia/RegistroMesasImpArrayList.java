/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Mesa;
import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public class RegistroMesasImpArrayList implements Serializable, ICrudRegistroMesa{
    private static final long serialVersionUID = 1L;
    private List<Mesa> listaMesas;
    private RegistroSalasImpArrayList salas;
    
    public RegistroMesasImpArrayList(){
        this.listaMesas = new ArrayList();
    }

    public List<Mesa> getListaMesas() {
        return listaMesas;
    }

    public void setListaMesas(List<Mesa> listaMesas) {
        this.listaMesas = listaMesas;
    }

    @Override
    public boolean crearMesa(Mesa mesa) {
        return this.listaMesas.add(mesa);
    }
    
    @Override
    public Mesa buscarMesa(int numMesa) {
        for(Mesa m : this.listaMesas){
            if(m.getNumero() == numMesa){
                return m;
            }
        }
        return null;
    }

    @Override
    public void agregarMesaASala(int numSala, int numMesa) {
        if(salas.buscarSala(numSala) == null){
            System.out.println("La sala no existe.");
        }else{
            if(this.buscarMesa(numMesa) == null){
                System.out.println("La mesa no existe.");
            }else{
                for(Sala s : this.salas.getListaSalas()){
                Mesa mesa = this.buscarMesa(numMesa);
                s.agregarUnaMesa(mesa);
                }
            }
        }
    }

    @Override
    public List<Mesa> getMesas() {
        return this.listaMesas;
    }

    @Override
    public boolean eliminarMesa(int id) {
        for(Mesa a : this.listaMesas){
            if(a.getNumero() == id){
                this.listaMesas.remove(a);
                return true;
            }
        }
        return false;
    }

    @Override
    public boolean editarMesa(Mesa mesa, String estado) {
        mesa.setEstado(estado);
        return true;
    }
}
