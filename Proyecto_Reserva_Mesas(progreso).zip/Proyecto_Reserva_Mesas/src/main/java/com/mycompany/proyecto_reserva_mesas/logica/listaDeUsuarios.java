package com.mycompany.proyecto_reserva_mesas.logica;

import com.mycompany.proyecto_reserva_mesas.entidades.Usuario;
import com.mycompany.proyecto_reserva_mesas.persistencia.ICrudRegistroUsuarios;
import com.mycompany.proyecto_reserva_mesas.persistencia.RegistroUsuariosArchivoObjeto;
import java.util.List;

public class listaDeUsuarios {
    private final String ADMIN_USER = "admin";
    private final String ADMIN_PASSWORD = "admin";
    private ICrudRegistroUsuarios persistencia;
    
    public listaDeUsuarios(){
        this.persistencia = new RegistroUsuariosArchivoObjeto();
    }
    
    public boolean login(String username, String password){
        if (ADMIN_USER.equals(username) && ADMIN_PASSWORD.equals(password)) {
            return true;
        } else {
            Usuario usuario = this.buscarUsuario(username);
            if (usuario != null && usuario.getContraseña().equals(password)) {
                return true;
            }
        }
        return false;
    }
    
    public boolean registrarUsuario(Usuario nuevo){
        return this.persistencia.añadirUsuario(nuevo);
    }
    
    public boolean eliminarUsuario(String eliminar){
        return this.persistencia.eliminarUsuario(eliminar);
    }
    
    public Usuario buscarUsuario(String username){
        return this.persistencia.buscarUsuario(username);
    }
    
    public String cambiarContrasenia(String username, String contrasenia){
        return this.persistencia.cambiarContrasenia(username, contrasenia);
    }
    
    public List<Usuario> obtenerDatos(){
        return this.persistencia.obtenerDatos();
    }
}
