package com.mycompany.proyecto_reserva_mesas.dto;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import javafx.beans.property.SimpleIntegerProperty;
import javafx.beans.property.SimpleStringProperty;

public class SalasDto {
    private SimpleIntegerProperty salas;
    private SimpleStringProperty descripcion;

    public SalasDto(Sala obj){
        this.salas = new SimpleIntegerProperty(obj.getSala());
        this.descripcion = new SimpleStringProperty(obj.getDescripcion());
    }

    public int getSala(){
        return salas.get();
    }

    public void setSala(int salas){
        this.salas.set(salas);
    }

    public String getDescripcion(){
        return descripcion.get();
    }

    public void setDescripcion(String descripcion){
        this.descripcion.set(descripcion);
    }

    public SimpleIntegerProperty salasProperty() {
        return salas;
    }

    public SimpleStringProperty descripcionProperty() {
        return descripcion;
    }
}
