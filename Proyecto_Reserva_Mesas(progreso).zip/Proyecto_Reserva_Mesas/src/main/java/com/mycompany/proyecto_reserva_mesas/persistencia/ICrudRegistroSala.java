/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.proyecto_reserva_mesas.persistencia;

import com.mycompany.proyecto_reserva_mesas.entidades.Sala;
import java.util.List;

/**
 *
 * @author Fabian Hinojosa
 */
public interface ICrudRegistroSala {
    
    Sala buscarSala(int numSala);
    boolean crearSala(Sala sala);
    boolean eliminarSala(int salaEliminar);
    List<Sala> getSalas();
}
